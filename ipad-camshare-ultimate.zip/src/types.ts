export type AppStep = 'setup' | 'active' | 'sender' | 'receiver';

export type VideoQuality = 'hd' | 'sd';

export interface StreamStats {
  resolution: string;
  fps: number;
  protocol: string;
  bitrate?: string;
}

export type ControlCommand = 'switch-camera' | 'toggle-torch' | 'toggle-saver';
