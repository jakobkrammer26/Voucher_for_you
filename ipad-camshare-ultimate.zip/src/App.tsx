import React, { useState, useEffect, useRef } from 'react';
import { Peer, MediaConnection, DataConnection } from 'peerjs';
import { 
  Camera, Video, Mic, MicOff, RotateCw, Tv, Sun, Maximize2, Minimize2, 
  Sparkles, Copy, Check, Settings, Power, Play, Square, Moon, RefreshCw, 
  Sliders, Download, HelpCircle, Activity, Info, AlertTriangle, Monitor, FlipHorizontal, Lock, CheckCircle, Smartphone
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AppStep, VideoQuality, StreamStats } from './types';

export default function App() {
  // Navigation & Step State
  const [step, setStep] = useState<AppStep>('setup');
  const [quality, setQuality] = useState<VideoQuality>('hd');
  const [statusText, setStatusText] = useState<string>('Schritt 1: Stream-Qualität wählen & Kamera aktivieren');
  const [localCode, setLocalCode] = useState<string>('');
  const [connectCode, setConnectCode] = useState<string>('');
  const [copyFeedback, setCopyFeedback] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // WebRTC / Stream states
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [myMicrophoneMuted, setMyMicrophoneMuted] = useState<boolean>(false);

  // Control and Remote States
  const [torchActive, setTorchActive] = useState<boolean>(false);
  const [saverActive, setSaverActive] = useState<boolean>(false); // local saver overlay
  const [remoteTorchActive, setRemoteTorchActive] = useState<boolean>(false);
  const [remoteSaverActive, setRemoteSaverActive] = useState<boolean>(false);

  // Viewport transformation states
  const [zoom, setZoom] = useState<number>(1);
  const [rotation, setRotation] = useState<number>(0);
  const [isMirrored, setIsMirrored] = useState<boolean>(false);
  const [brightness, setBrightness] = useState<number>(100);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  // Recording State
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordingSeconds, setRecordingSeconds] = useState<number>(0);

  // Refs for tracking mutable variables without re-triggering state loops
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);
  const peerRef = useRef<Peer | null>(null);
  const callRef = useRef<MediaConnection | null>(null);
  const dataConnRef = useRef<DataConnection | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const recordingIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const initialPinchDistRef = useRef<number>(0);

  // Initialize random peer code
  useEffect(() => {
    const randomId = Math.floor(1000 + Math.random() * 9000).toString();
    setLocalCode(randomId);
    
    // Cleanup WebRTC connections on unmount
    return () => {
      cleanupConnections();
    };
  }, []);

  // Sync state streams to video elements
  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream, step]);

  useEffect(() => {
    if (remoteVideoRef.current && remoteStream) {
      remoteVideoRef.current.srcObject = remoteStream;
    }
  }, [remoteStream, step]);

  // Handle Recording timer
  useEffect(() => {
    if (isRecording) {
      recordingSecondsRef.current = 0;
      setRecordingSeconds(0);
      recordingIntervalRef.current = setInterval(() => {
        setRecordingSeconds(prev => prev + 1);
      }, 1000);
    } else {
      if (recordingIntervalRef.current) {
        clearInterval(recordingIntervalRef.current);
        recordingIntervalRef.current = null;
      }
    }
    return () => {
      if (recordingIntervalRef.current) {
        clearInterval(recordingIntervalRef.current);
      }
    };
  }, [isRecording]);

  const recordingSecondsRef = useRef<number>(0);

  // Function to completely clean up WebRTC
  const cleanupConnections = () => {
    if (mediaRecorderRef.current && isRecording) {
      try {
        mediaRecorderRef.current.stop();
      } catch (e) {}
    }

    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
    }
    
    if (callRef.current) {
      callRef.current.close();
    }
    
    if (dataConnRef.current) {
      dataConnRef.current.close();
    }

    if (peerRef.current) {
      peerRef.current.destroy();
    }

    setLocalStream(null);
    setRemoteStream(null);
    setIsRecording(false);
    setStep('setup');
    setStatusText('Schritt 1: Stream-Qualität wählen & Kamera aktivieren');
  };

  // 1. Initialize local camera
  const initLocalCamera = async () => {
    const videoWidth = quality === 'hd' ? 1280 : 640;
    const videoHeight = quality === 'hd' ? 720 : 360;

    try {
      setStatusText('Greife auf Kamera und Mikrofon zu...');
      setErrorMessage(null);
      
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: facingMode,
          width: { ideal: videoWidth },
          height: { ideal: videoHeight }
        },
        audio: true
      });

      setLocalStream(stream);
      setStep('active');
      setStatusText('Bereit! Koppelungscode generiert.');
      
      // Initialize PeerJS
      initPeer(stream);
    } catch (err: any) {
      console.error(err);
      setErrorMessage(`Kamerafehler: ${err.message || 'Zugriff verweigert'}`);
      setStatusText('Kamerafehler. Bitte Berechtigungen prüfen.');
    }
  };

  // 2. Initialize PeerJS
  const initPeer = (stream: MediaStream) => {
    const peerId = `ipad-rtc-${localCode}`;
    
    // Connect to PeerJS cloud server securely
    const peer = new Peer(peerId, {
      host: '0.peerjs.com',
      port: 443,
      secure: true,
      debug: 1
    });

    peerRef.current = peer;

    peer.on('open', () => {
      setStatusText(`Kamera aktiv. Koppelungs-Code: ${localCode}`);
    });

    peer.on('error', (err) => {
      console.error('PeerJS error:', err);
      setErrorMessage(`Netzwerkfehler: ${err.type}`);
    });

    // When someone calls us (we act as Sender / Passive Camera)
    peer.on('call', (incomingCall) => {
      transformToSenderMode();
      callRef.current = incomingCall;
      
      // Answer with our stream
      incomingCall.answer(stream);
      
      incomingCall.on('stream', (incomingStream) => {
        setRemoteStream(incomingStream);
      });
    });

    // When someone initiates data connection (for remote commands)
    peer.on('connection', (conn) => {
      dataConnRef.current = conn;
      setupDataListener(conn);
    });
  };

  // 3. Connect to remote sender (We act as Controller / Receiver)
  const startConnection = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!connectCode || connectCode.trim().length !== 4) {
      setErrorMessage('Bitte gib einen gültigen 4-stelligen Code ein.');
      return;
    }

    const targetPeerId = `ipad-rtc-${connectCode.trim()}`;
    setStatusText(`Verbinde mit Sender-Kamera (Code: ${connectCode})...`);
    setErrorMessage(null);

    if (!peerRef.current || !localStream) {
      setErrorMessage('Kamera ist nicht initialisiert.');
      return;
    }

    // Connect data channel
    const conn = peerRef.current.connect(targetPeerId);
    dataConnRef.current = conn;
    setupDataListener(conn);

    // Call the remote peer
    const call = peerRef.current.call(targetPeerId, localStream);
    callRef.current = call;

    call.on('stream', (incomingStream) => {
      transformToReceiverMode();
      setRemoteStream(incomingStream);
      setStatusText('Erfolgreich gekoppelt! Live-Kanal aktiv.');
    });

    call.on('error', (err) => {
      setErrorMessage(`Koppelungsfehler: ${err.message}`);
    });
  };

  // Transform views on connect
  const transformToSenderMode = () => {
    setStep('sender');
    setStatusText('🔴 Live-Übertragung läuft. (Dieses iPad wird ferngesteuert)');
  };

  const transformToReceiverMode = () => {
    setStep('receiver');
  };

  // Remote command handlers
  const setupDataListener = (conn: DataConnection) => {
    conn.on('data', async (data) => {
      if (data === 'switch-camera') {
        await switchLocalCamera();
      } else if (data === 'toggle-torch') {
        toggleLocalTorch();
      } else if (data === 'toggle-saver') {
        toggleLocalSaver();
      }
    });

    conn.on('close', () => {
      setStatusText('Verbindung vom Partner beendet.');
      cleanupConnections();
    });
  };

  // Remote actions sent by Receiver to Sender
  const requestRemoteCameraSwitch = () => {
    if (dataConnRef.current && dataConnRef.current.open) {
      dataConnRef.current.send('switch-camera');
      setStatusText('Kamera drüben wird gewechselt...');
    }
  };

  const requestRemoteTorch = () => {
    if (dataConnRef.current && dataConnRef.current.open) {
      dataConnRef.current.send('toggle-torch');
      setRemoteTorchActive(!remoteTorchActive);
      setStatusText(!remoteTorchActive ? 'Taschenlampe drüben eingeschaltet' : 'Taschenlampe drüben ausgeschaltet');
    }
  };

  const requestRemoteSaver = () => {
    if (dataConnRef.current && dataConnRef.current.open) {
      dataConnRef.current.send('toggle-saver');
      setRemoteSaverActive(!remoteSaverActive);
      setStatusText('Standby-Befehl drüben gesendet.');
    }
  };

  // Local camera toggles (Self-executed when commanded remotely)
  const switchLocalCamera = async () => {
    if (!localStream) return;
    const nextFacing = facingMode === 'environment' ? 'user' : 'environment';
    setFacingMode(nextFacing);

    try {
      const videoWidth = quality === 'hd' ? 1280 : 640;
      const videoHeight = quality === 'hd' ? 720 : 360;

      const newStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: nextFacing, width: { ideal: videoWidth }, height: { ideal: videoHeight } },
        audio: true
      });

      const newTrack = newStream.getVideoTracks()[0];
      setLocalStream(newStream);

      // Replace track on existing peer connection
      if (callRef.current && callRef.current.peerConnection) {
        const senders = callRef.current.peerConnection.getSenders();
        const videoSender = senders.find(sender => sender.track && sender.track.kind === 'video');
        if (videoSender) {
          await videoSender.replaceTrack(newTrack);
        }
      }

      // Stop old tracks
      localStream.getTracks().forEach(track => track.stop());
    } catch (err: any) {
      console.error(err);
      setStatusText(`Fehler beim Kamerawechsel: ${err.message}`);
    }
  };

  const toggleLocalTorch = async () => {
    if (!localStream) return;
    const videoTrack = localStream.getVideoTracks()[0];
    try {
      const capabilities = videoTrack.getCapabilities() as any;
      if (capabilities.torch) {
        const constraints = videoTrack.getConstraints();
        const currentTorchState = constraints.advanced && (constraints.advanced[0] as any).torch;
        await videoTrack.applyConstraints({
          advanced: [{ torch: !currentTorchState }]
        } as any);
        setTorchActive(!currentTorchState);
      } else {
        setStatusText('Gerät unterstützt keine Taschenlampe / Blitz.');
      }
    } catch (err: any) {
      console.log('Flashlight error:', err);
    }
  };

  const toggleLocalSaver = () => {
    setSaverActive(prev => !prev);
  };

  // Mic stummschalten (intercom toggle)
  const toggleLocalMute = () => {
    if (!localStream) return;
    const audioTrack = localStream.getAudioTracks()[0];
    if (audioTrack) {
      const nextMuted = !myMicrophoneMuted;
      audioTrack.enabled = !nextMuted;
      setMyMicrophoneMuted(nextMuted);
      setStatusText(nextMuted ? 'Mein Mikrofon stummgeschaltet' : 'Mein Mikrofon aktiv');
    }
  };

  // Take photo from active stream with canvas rendering
  const takePhoto = () => {
    const video = remoteVideoRef.current?.srcObject ? remoteVideoRef.current : localVideoRef.current;
    if (!video || !video.srcObject) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const vWidth = video.videoWidth || 1280;
    const vHeight = video.videoHeight || 720;

    canvas.width = vWidth;
    canvas.height = vHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.save();
    // Center transformations
    ctx.translate(vWidth / 2, vHeight / 2);

    if (isMirrored) {
      ctx.scale(-1, 1);
    }

    ctx.rotate((rotation * Math.PI) / 180);
    ctx.filter = `brightness(${brightness}%)`;

    // Draw video from center
    ctx.drawImage(video, -vWidth / 2, -vHeight / 2, vWidth, vHeight);
    ctx.restore();

    // Trigger download
    const dataURL = canvas.toDataURL('image/png');
    const link = document.createElement('a');
    link.download = `Photo_${Date.now()}.png`;
    link.href = dataURL;
    link.click();
    
    setStatusText('📸 Foto erfolgreich im Downloads-Ordner gespeichert!');
  };

  // Record Stream
  const toggleRecording = () => {
    const streamToRecord = remoteStream || localStream;
    if (!streamToRecord) return;

    if (!isRecording) {
      recordedChunksRef.current = [];
      let options: MediaRecorderOptions = { mimeType: 'video/mp4' };
      if (!MediaRecorder.isTypeSupported(options.mimeType!)) {
        options = { mimeType: 'video/webm' };
      }

      try {
        const recorder = new MediaRecorder(streamToRecord, options);
        mediaRecorderRef.current = recorder;

        recorder.ondataavailable = (event) => {
          if (event.data && event.data.size > 0) {
            recordedChunksRef.current.push(event.data);
          }
        };

        recorder.onstop = () => {
          const blob = new Blob(recordedChunksRef.current, { type: mediaRecorderRef.current?.mimeType || 'video/mp4' });
          const url = URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.download = `Video_Record_${Date.now()}.mp4`;
          link.href = url;
          link.click();
          setStatusText('🔴 Aufnahme erfolgreich exportiert!');
        };

        recorder.start();
        setIsRecording(true);
        setStatusText('🔴 Aufnahme läuft...');
      } catch (err: any) {
        console.error('Recording initialization error:', err);
        setErrorMessage(`Aufnahmefehler: ${err.message}`);
      }
    } else {
      if (mediaRecorderRef.current) {
        mediaRecorderRef.current.stop();
      }
      setIsRecording(false);
    }
  };

  // Helper formatting for seconds
  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Transformations
  const rotateVideo = () => {
    setRotation(prev => (prev + 90) % 360);
  };

  const mirrorVideo = () => {
    setIsMirrored(prev => !prev);
  };

  const applyZoom = (val: number) => {
    setZoom(val);
  };

  const applyBrightness = (val: number) => {
    setBrightness(val);
  };

  // Pinch-to-zoom gesture trackers
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      const dist = Math.hypot(
        e.touches[0].pageX - e.touches[1].pageX,
        e.touches[0].pageY - e.touches[1].pageY
      );
      initialPinchDistRef.current = dist;
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 2 && initialPinchDistRef.current > 0) {
      const dist = Math.hypot(
        e.touches[0].pageX - e.touches[1].pageX,
        e.touches[0].pageY - e.touches[1].pageY
      );
      const factor = dist / initialPinchDistRef.current;
      const newZoom = Math.min(Math.max(zoom * factor, 1), 4);
      setZoom(Number(newZoom.toFixed(1)));
      initialPinchDistRef.current = dist;
    }
  };

  const handleTouchEnd = () => {
    initialPinchDistRef.current = 0;
  };

  // Toggle fullscreen theater view on controller
  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  // Copy code to clipboard
  const copyToClipboard = () => {
    navigator.clipboard.writeText(localCode);
    setCopyFeedback(true);
    setTimeout(() => setCopyFeedback(false), 2000);
  };

  return (
    <div className="min-h-screen bg-black text-white font-sans flex flex-col justify-between selection:bg-emerald-500 selection:text-black">
      {/* 1. Header Area - Sticky & Premium Glassmorphic */}
      {!isFullscreen && (
        <header className="border-b border-zinc-800 bg-zinc-950/80 backdrop-blur-md px-6 py-4 sticky top-0 z-50">
          <div className="max-w-6xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.15)]">
                <Tv className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <h1 className="text-xl font-bold font-display tracking-tight text-white flex items-center gap-2">
                  iPad CamShare Ultimate <span className="text-[10px] uppercase font-mono tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/20">Cockpit v2.0</span>
                </h1>
                <p className="text-xs text-zinc-400">P2P Echtzeit Kamera & Fernsteuerung für iPads</p>
              </div>
            </div>

            {/* Live Indicator Panel */}
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-zinc-900 border border-zinc-800 text-xs">
                <span className={`w-2.5 h-2.5 rounded-full ${
                  step === 'setup' ? 'bg-zinc-600' : 
                  step === 'active' ? 'bg-amber-400 animate-pulse' : 
                  step === 'sender' ? 'bg-rose-500 animate-pulse indicator-glow-red' : 
                  'bg-emerald-400 animate-pulse indicator-glow-green'
                }`} />
                <span className="font-mono text-zinc-300">
                  Status: {
                    step === 'setup' ? 'Bereitstellen' : 
                    step === 'active' ? 'Bereit zum Koppeln' : 
                    step === 'sender' ? 'Sender (Aktiv)' : 
                    'Receiver Cockpit'
                  }
                </span>
              </div>

              {step !== 'setup' && (
                <button 
                  onClick={cleanupConnections}
                  className="px-3.5 py-1.5 rounded-full bg-red-950/50 hover:bg-red-900 text-red-200 border border-red-800/60 text-xs font-medium transition flex items-center gap-1.5 cursor-pointer active:scale-95"
                >
                  <Power className="w-3.5 h-3.5" />
                  <span>Trennen</span>
                </button>
              )}
            </div>
          </div>
        </header>
      )}

      {/* Main Container Area */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-4 md:p-6 flex flex-col justify-center">
        {/* Status Messages bar */}
        {!isFullscreen && (
          <div className="mb-4">
            <div className="glass-panel px-4 py-3 rounded-2xl flex items-center gap-3 border-zinc-800/80">
              <Activity className="w-4 h-4 text-emerald-400 shrink-0" />
              <p className="text-xs md:text-sm font-medium text-zinc-200">{statusText}</p>
            </div>
          </div>
        )}

        {/* Global Error Banner */}
        {errorMessage && (
          <div className="mb-4 bg-red-950/40 border border-red-800/50 p-4 rounded-2xl flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            <div className="flex-1">
              <h4 className="text-sm font-semibold text-red-200">Systemwarnung</h4>
              <p className="text-xs text-red-300 mt-0.5">{errorMessage}</p>
            </div>
            <button onClick={() => setErrorMessage(null)} className="text-xs text-zinc-400 hover:text-white underline cursor-pointer">Ausblenden</button>
          </div>
        )}

        {/* STEP 1: INITIAL SETUP */}
        <AnimatePresence mode="wait">
          {step === 'setup' && (
            <motion.div 
              key="setup"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="grid md:grid-cols-12 gap-6 items-center"
            >
              {/* Marketing and Description Card */}
              <div className="md:col-span-7 space-y-6">
                <div className="space-y-3">
                  <span className="text-xs uppercase tracking-wider font-mono px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">Peer-to-Peer Streaming</span>
                  <h2 className="text-3xl md:text-4xl font-extrabold font-display leading-tight tracking-tight text-white">
                    Verwandle dein altes iPad in eine kabellose Remote-Kamera.
                  </h2>
                  <p className="text-zinc-400 text-sm md:text-base leading-relaxed">
                    iPad CamShare Ultimate verbindet zwei iPads über eine sichere, verzögerungsfreie Direktverbindung (WebRTC). Steuere die Kamera drüben, zoome, schalte Licht an und nimm Videos direkt auf dem Empfänger-Tablet auf.
                  </p>
                </div>

                {/* Specs Bento Grid */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-zinc-900/60 p-4 rounded-2xl border border-zinc-800/60">
                    <div className="text-emerald-400 font-bold text-lg font-mono">0ms Lag</div>
                    <div className="text-zinc-500 text-xs mt-1">Direkte WebRTC P2P-Verbindung ohne Server-Verzögerung</div>
                  </div>
                  <div className="bg-zinc-900/60 p-4 rounded-2xl border border-zinc-800/60">
                    <div className="text-blue-400 font-bold text-lg font-mono">Remotesteuerung</div>
                    <div className="text-zinc-500 text-xs mt-1">Blitzlicht, Zoom, Spiegelfunktion & Kamerawechsel aus der Ferne</div>
                  </div>
                </div>
              </div>

              {/* Action Start Form Panel */}
              <div className="md:col-span-5 bg-zinc-900/80 rounded-3xl p-6 border border-zinc-800/80 shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
                
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <Settings className="w-5 h-5 text-emerald-400" />
                  Kamera-Station starten
                </h3>

                {/* Option 1: Quality Selector */}
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2">Auflösung & Stream-Qualität</label>
                    <div className="grid grid-cols-2 gap-3">
                      <button 
                        type="button"
                        onClick={() => setQuality('hd')}
                        className={`p-3 rounded-xl border text-left transition relative cursor-pointer ${
                          quality === 'hd' 
                            ? 'bg-emerald-950/20 border-emerald-500/50 text-white shadow-[0_0_15px_rgba(16,185,129,0.05)]' 
                            : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-700'
                        }`}
                      >
                        <span className="block text-xs font-bold">HD (720p)</span>
                        <span className="block text-[10px] text-zinc-500 mt-1">Ideal für starke Wi-Fi Verbindungen</span>
                        {quality === 'hd' && <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-emerald-400" />}
                      </button>

                      <button 
                        type="button"
                        onClick={() => setQuality('sd')}
                        className={`p-3 rounded-xl border text-left transition relative cursor-pointer ${
                          quality === 'sd' 
                            ? 'bg-emerald-950/20 border-emerald-500/50 text-white shadow-[0_0_15px_rgba(16,185,129,0.05)]' 
                            : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-700'
                        }`}
                      >
                        <span className="block text-xs font-bold">SD (360p)</span>
                        <span className="block text-[10px] text-zinc-500 mt-1">Datensparend & schnellere Latenz</span>
                        {quality === 'sd' && <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-emerald-400" />}
                      </button>
                    </div>
                  </div>

                  {/* Camera Face Selector */}
                  <div>
                    <label className="block text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2">Standard-Kamera</label>
                    <div className="grid grid-cols-2 gap-3">
                      <button 
                        type="button"
                        onClick={() => setFacingMode('environment')}
                        className={`p-3 rounded-xl border text-left transition relative cursor-pointer ${
                          facingMode === 'environment' 
                            ? 'bg-emerald-950/20 border-emerald-500/50 text-white' 
                            : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-700'
                        }`}
                      >
                        <span className="block text-xs font-bold">Rückkamera</span>
                        <span className="block text-[10px] text-zinc-500 mt-1">Ideal für Hauptansichten</span>
                        {facingMode === 'environment' && <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-emerald-400" />}
                      </button>

                      <button 
                        type="button"
                        onClick={() => setFacingMode('user')}
                        className={`p-3 rounded-xl border text-left transition relative cursor-pointer ${
                          facingMode === 'user' 
                            ? 'bg-emerald-950/20 border-emerald-500/50 text-white' 
                            : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-700'
                        }`}
                      >
                        <span className="block text-xs font-bold">Frontkamera</span>
                        <span className="block text-[10px] text-zinc-500 mt-1">Für Selfies / Konferenzen</span>
                        {facingMode === 'user' && <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-emerald-400" />}
                      </button>
                    </div>
                  </div>

                  {/* Primary Trigger Button */}
                  <button
                    onClick={initLocalCamera}
                    className="w-full py-4 px-6 bg-emerald-500 hover:bg-emerald-400 text-black font-bold rounded-2xl transition shadow-lg shadow-emerald-500/20 active:scale-95 cursor-pointer flex items-center justify-center gap-2 mt-2"
                  >
                    <Play className="w-5 h-5 fill-current" />
                    <span>1. Kamera & Station Aktivieren</span>
                  </button>

                  <div className="text-zinc-500 text-[11px] text-center mt-3">
                    Sie müssen den Zugriff auf Kamera und Mikrofon erlauben, um die WebRTC Verbindung aufzubauen.
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* STEP 2: ACTIVE AND READY FOR COUPLING */}
          {step === 'active' && (
            <motion.div 
              key="active"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className="grid md:grid-cols-12 gap-6 items-stretch"
            >
              {/* Option A: Sender Panel with local preview */}
              <div className="md:col-span-6 bg-zinc-900/60 p-6 rounded-3xl border border-zinc-800 flex flex-col justify-between relative overflow-hidden">
                <div className="absolute top-4 right-4 z-10 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur text-amber-400 text-[10px] font-mono border border-amber-400/20">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
                  Wartet auf Empfänger
                </div>

                <div>
                  <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
                    <Smartphone className="w-5 h-5 text-emerald-400" />
                    Als Kamera-iPad nutzen
                  </h3>
                  <p className="text-zinc-400 text-xs mb-4">
                    Dieses iPad dient als Kamera-Sender. Trage diesen Code auf dem Empfänger-iPad ein, um das Cockpit zu starten.
                  </p>

                  {/* Large visual Code Area */}
                  <div className="bg-black/50 border border-zinc-800 rounded-2xl p-5 text-center my-4 relative">
                    <div className="text-[10px] text-zinc-500 uppercase tracking-wider font-mono font-bold mb-1">Verbindungs-Code</div>
                    <div className="text-5xl font-extrabold text-emerald-400 tracking-widest font-mono select-all">
                      {localCode}
                    </div>
                    
                    <button 
                      onClick={copyToClipboard}
                      className="absolute bottom-3 right-3 p-2 bg-zinc-900 border border-zinc-800 hover:border-zinc-700 rounded-xl transition text-zinc-400 hover:text-white cursor-pointer active:scale-95"
                      title="Code kopieren"
                    >
                      {copyFeedback ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Local preview window */}
                <div className="relative aspect-video bg-black rounded-2xl border border-zinc-800 overflow-hidden mt-2">
                  <video 
                    ref={localVideoRef} 
                    autoPlay 
                    playsInline 
                    muted 
                    className="w-full h-full object-cover scale-x-[-1]"
                  />
                  <div className="absolute bottom-2 left-2 px-2 py-0.5 rounded bg-black/70 text-[9px] text-zinc-400 font-mono">
                    Lokales Kamerabild
                  </div>
                </div>
              </div>

              {/* Option B: Connect as Controller / Receiver */}
              <div className="md:col-span-6 bg-zinc-900/80 p-6 rounded-3xl border border-emerald-500/20 shadow-xl flex flex-col justify-between relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
                
                <div>
                  <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
                    <Tv className="w-5 h-5 text-emerald-400" />
                    Als Cockpit / Empfänger nutzen
                  </h3>
                  <p className="text-zinc-400 text-xs mb-6">
                    Trage hier den 4-stelligen Koppelungscode des anderen iPads ein, um dessen Kamera live zu sehen und fernzusteuern.
                  </p>

                  <form onSubmit={startConnection} className="space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-zinc-500 uppercase tracking-widest mb-2">Code des Partners eingeben</label>
                      <input 
                        type="text" 
                        maxLength={4}
                        placeholder="Z.B. 4812"
                        value={connectCode}
                        onChange={(e) => setConnectCode(e.target.value.replace(/\D/g, ''))}
                        className="w-full bg-black border-2 border-zinc-800 hover:border-zinc-700 focus:border-emerald-500 rounded-2xl py-4 text-center text-4xl font-extrabold text-white tracking-widest font-mono outline-none transition"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={!connectCode || connectCode.length !== 4}
                      className={`w-full py-4 rounded-2xl font-bold transition flex items-center justify-center gap-2 cursor-pointer ${
                        connectCode.length === 4 
                          ? 'bg-emerald-500 hover:bg-emerald-400 text-black shadow-lg shadow-emerald-500/10 active:scale-95' 
                          : 'bg-zinc-800 text-zinc-500 cursor-not-allowed opacity-50'
                      }`}
                    >
                      <CheckCircle className="w-5 h-5" />
                      <span>2. Cockpit koppeln</span>
                    </button>
                  </form>
                </div>

                {/* Helpful tip overlay */}
                <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-4 mt-6 flex gap-3 items-start">
                  <Info className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <p className="text-[11px] text-zinc-400 leading-relaxed">
                    <b>Tipp:</b> Du kannst diese Seite auf zwei verschiedenen Geräten (z.B. iPhone & iPad) laden. Die Verbindung wird direkt über verschlüsseltes Peer-to-Peer aufgebaut, ohne dass Videodaten über fremde Server fließen.
                  </p>
                </div>
              </div>
            </motion.div>
          )}

          {/* STEP 3: SENDER MODE (PASSIVE STREAMING FOR HOST) */}
          {step === 'sender' && (
            <motion.div 
              key="sender"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="relative w-full aspect-video bg-zinc-950 rounded-3xl border-2 border-zinc-800 overflow-hidden group shadow-2xl flex items-center justify-center"
            >
              <video 
                ref={localVideoRef} 
                autoPlay 
                playsInline 
                muted 
                className="w-full h-full object-cover scale-x-[-1]"
              />

              {/* Status Indicator Overlays */}
              <div className="absolute top-4 left-4 z-20 flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/75 backdrop-blur text-xs font-medium border border-zinc-800">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse indicator-glow-red" />
                <span className="text-zinc-300">🔴 Live-Übertragung an Empfänger</span>
              </div>

              {/* Floating manual camera orientation switcher (just in case they need to override local side) */}
              <div className="absolute top-4 right-4 z-20 flex gap-2">
                <button
                  onClick={switchLocalCamera}
                  className="p-3 bg-black/75 hover:bg-zinc-900 rounded-full border border-zinc-800 transition text-white hover:text-emerald-400 cursor-pointer active:scale-95"
                  title="Kamera wechseln"
                >
                  <RefreshCw className="w-5 h-5" />
                </button>
                <button
                  onClick={toggleLocalTorch}
                  className="p-3 bg-black/75 hover:bg-zinc-900 rounded-full border border-zinc-800 transition text-white hover:text-amber-400 cursor-pointer active:scale-95"
                  title="Blitzlicht ein-/ausschalten"
                >
                  <Sun className={`w-5 h-5 ${torchActive ? 'text-amber-400 animate-spin' : ''}`} />
                </button>
              </div>

              {/* Info Overlay inside frame */}
              <div className="absolute bottom-4 left-4 right-4 z-20 bg-black/80 backdrop-blur-md p-4 rounded-2xl border border-zinc-800 max-w-lg mx-auto">
                <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-widest mb-1">Fernsteuerung aktiv</h4>
                <p className="text-[11px] text-zinc-400 leading-relaxed">
                  Dieses iPad wird jetzt vom Partner-Gerät gesteuert. Der Monitor kann ferngesteuert ausgeschaltet werden, um Akku zu sparen. Drücke unten auf "Beenden", um das Streamen zu beenden.
                </p>
              </div>

              {/* SAVER OVERLAY (ENERGY SAVING mode triggered remotely) */}
              {saverActive && (
                <div className="absolute inset-0 bg-black z-40 flex flex-col items-center justify-center p-6 text-center select-none">
                  <div className="w-16 h-16 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-500 mb-4">
                    <Moon className="w-8 h-8 text-zinc-400 animate-pulse" />
                  </div>
                  <h3 className="text-sm font-bold text-zinc-300">Energiesparmodus aktiv</h3>
                  <p className="text-xs text-zinc-500 mt-1 max-w-xs">
                    Der Bildschirm wurde abgedunkelt, um Akkulaufzeit zu schonen. Der Kamera-Stream läuft im Hintergrund weiter.
                  </p>
                  
                  {/* Small settings button inside pitch-black to manually escape */}
                  <button 
                    onClick={toggleLocalSaver}
                    className="mt-6 px-4 py-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 text-xs rounded-xl border border-zinc-800 transition cursor-pointer active:scale-95"
                  >
                    Bildschirm reaktivieren
                  </button>
                </div>
              )}
            </motion.div>
          )}

          {/* STEP 4: RECEIVER COCKPIT (THE CONTROL SUITE) */}
          {step === 'receiver' && (
            <motion.div 
              key="receiver"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="grid lg:grid-cols-12 gap-6 items-start"
            >
              {/* Left Main Viewport (7 cols) */}
              <div className={`lg:col-span-8 ${isFullscreen ? 'lg:col-span-12 w-full h-[85vh]' : ''} transition-all duration-300`}>
                <div 
                  id="viewports"
                  onTouchStart={handleTouchStart}
                  onTouchMove={handleTouchMove}
                  onTouchEnd={handleTouchEnd}
                  className="relative aspect-video bg-zinc-950 rounded-3xl border-2 border-zinc-800 overflow-hidden shadow-2xl flex items-center justify-center group"
                >
                  <video 
                    ref={remoteVideoRef} 
                    autoPlay 
                    playsInline 
                    className="w-full h-full object-contain transition-all duration-300 ease-out"
                    style={{
                      transform: `scale(${zoom}) rotate(${rotation}deg) scaleX(${isMirrored ? -1 : 1})`,
                      filter: `brightness(${brightness}%)`
                    }}
                  />

                  {/* Watermark/Stats overlay */}
                  <div className="absolute top-4 left-4 z-20 pointer-events-none flex flex-col gap-1">
                    <div className="px-2.5 py-1 rounded bg-black/70 backdrop-blur border border-white/10 text-[9px] font-mono text-emerald-400 uppercase tracking-widest flex items-center gap-1.5 shadow-md">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                      Live Stream
                    </div>
                    
                    <div className="flex gap-1">
                      {zoom > 1 && (
                        <div className="px-1.5 py-0.5 rounded bg-black/60 backdrop-blur text-[8px] font-mono text-zinc-300 uppercase">
                          Zoom: {zoom.toFixed(1)}x
                        </div>
                      )}
                      {rotation > 0 && (
                        <div className="px-1.5 py-0.5 rounded bg-black/60 backdrop-blur text-[8px] font-mono text-zinc-300 uppercase">
                          Winkel: {rotation}°
                        </div>
                      )}
                      {isMirrored && (
                        <div className="px-1.5 py-0.5 rounded bg-black/60 backdrop-blur text-[8px] font-mono text-zinc-300 uppercase">
                          Spiegelung
                        </div>
                      )}
                      {brightness !== 100 && (
                        <div className="px-1.5 py-0.5 rounded bg-black/60 backdrop-blur text-[8px] font-mono text-zinc-300 uppercase">
                          Belichtung: {brightness}%
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Video recording ongoing banner */}
                  {isRecording && (
                    <div className="absolute top-4 right-4 z-20 px-3 py-1 rounded-full bg-red-950/80 backdrop-blur border border-red-800/80 text-[10px] text-red-200 font-mono tracking-widest flex items-center gap-2 animate-recording-blink shadow-lg">
                      <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
                      REC {formatTime(recordingSeconds)}
                    </div>
                  )}

                  {/* Theater Mode Exit overlay triggers on click / touch */}
                  {isFullscreen && (
                    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 opacity-0 group-hover:opacity-100 transition duration-300">
                      <button 
                        onClick={toggleFullscreen}
                        className="px-4 py-2 bg-black/80 hover:bg-zinc-900 border border-zinc-800 text-white rounded-full flex items-center gap-2 text-xs shadow-lg cursor-pointer"
                      >
                        <Minimize2 className="w-4 h-4" />
                        <span>Bedienfeld einblenden</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* Subtext info for touch interaction */}
                <div className="flex justify-between items-center px-2 py-2 text-zinc-500 text-[10px] font-mono">
                  <span>WebRTC P2P-Direktverbindung</span>
                  <span className="hidden sm:inline">Pinch-to-zoom (2 Finger) auf dem Videobild unterstützt</span>
                </div>
              </div>

              {/* Right Sidebar Controllers (4 cols) */}
              {!isFullscreen && (
                <div className="lg:col-span-4 space-y-5">
                  
                  {/* Action Bento Card A: CAPTURING & EXPORTS */}
                  <div className="bg-zinc-900/60 rounded-2xl p-4 border border-zinc-800/80 space-y-3 shadow-md relative overflow-hidden">
                    <h3 className="text-xs uppercase tracking-widest font-mono font-bold text-zinc-400 border-b border-zinc-800 pb-2 flex items-center gap-1.5">
                      <Download className="w-4 h-4 text-emerald-400" />
                      Aufnahme & Export
                    </h3>

                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={takePhoto}
                        className="py-3 px-4 bg-zinc-800 hover:bg-zinc-700 text-white font-bold rounded-xl transition flex items-center justify-center gap-2 text-xs cursor-pointer active:scale-95"
                      >
                        <span>📸 Foto</span>
                      </button>

                      <button
                        onClick={toggleRecording}
                        className={`py-3 px-4 font-bold rounded-xl transition flex items-center justify-center gap-2 text-xs cursor-pointer active:scale-95 ${
                          isRecording 
                            ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-[0_0_15px_rgba(239,68,68,0.2)]' 
                            : 'bg-red-950/40 border border-red-800 text-red-400 hover:bg-red-950/80'
                        }`}
                      >
                        <span className={`w-2 h-2 rounded-full bg-red-500 ${isRecording ? 'animate-ping' : ''}`} />
                        <span>{isRecording ? '⏹ Stoppen' : '🔴 Aufnahme'}</span>
                      </button>
                    </div>

                    {/* Microphone toggle for backtalk/intercom */}
                    <button
                      onClick={toggleLocalMute}
                      className={`w-full py-3 px-4 rounded-xl font-semibold transition text-xs flex items-center justify-center gap-2 cursor-pointer ${
                        myMicrophoneMuted 
                          ? 'bg-zinc-800 text-zinc-400 hover:bg-zinc-700' 
                          : 'bg-emerald-950/40 border border-emerald-800 text-emerald-400 hover:bg-emerald-950/80'
                      }`}
                    >
                      {myMicrophoneMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4 animate-bounce" />}
                      <span>{myMicrophoneMuted ? '🔇 Mein Mikrofon: Aus (Stumm)' : '🔊 Mein Mikrofon: An (Gegensprechen)'}</span>
                    </button>
                  </div>

                  {/* Action Bento Card B: VIDEO MANIPULATIONS */}
                  <div className="bg-zinc-900/60 rounded-2xl p-4 border border-zinc-800/80 space-y-4 shadow-md">
                    <h3 className="text-xs uppercase tracking-widest font-mono font-bold text-zinc-400 border-b border-zinc-800 pb-2 flex items-center gap-1.5">
                      <Sliders className="w-4 h-4 text-emerald-400" />
                      Bild-Justierung
                    </h3>

                    {/* Rotation, Mirror, Switch */}
                    <div className="grid grid-cols-3 gap-2">
                      <button
                        onClick={rotateVideo}
                        className="py-2.5 px-2 bg-zinc-800 hover:bg-zinc-700 rounded-xl transition flex flex-col items-center gap-1 text-[10px] font-bold text-zinc-300 cursor-pointer active:scale-95"
                      >
                        <RotateCw className="w-4 h-4 text-emerald-400" />
                        <span>90° Drehen</span>
                      </button>

                      <button
                        onClick={mirrorVideo}
                        className="py-2.5 px-2 bg-zinc-800 hover:bg-zinc-700 rounded-xl transition flex flex-col items-center gap-1 text-[10px] font-bold text-zinc-300 cursor-pointer active:scale-95"
                      >
                        <FlipHorizontal className="w-4 h-4 text-emerald-400" />
                        <span>Spiegeln</span>
                      </button>

                      <button
                        onClick={requestRemoteCameraSwitch}
                        className="py-2.5 px-2 bg-zinc-850 hover:bg-zinc-850/80 border border-zinc-700 rounded-xl transition flex flex-col items-center gap-1 text-[10px] font-bold text-zinc-200 cursor-pointer active:scale-95"
                      >
                        <Camera className="w-4 h-4 text-emerald-400" />
                        <span>Cam drüben</span>
                      </button>
                    </div>

                    {/* Brightness, zoom sliders */}
                    <div className="space-y-4 pt-2">
                      <div className="space-y-1.5">
                        <div className="flex justify-between text-[11px] font-semibold text-zinc-400">
                          <span className="flex items-center gap-1"><Maximize2 className="w-3.5 h-3.5" /> Zoom</span>
                          <span className="font-mono text-emerald-400">{zoom.toFixed(1)}x</span>
                        </div>
                        <input 
                          type="range" 
                          min="1" 
                          max="4" 
                          step="0.1" 
                          value={zoom} 
                          onChange={(e) => applyZoom(parseFloat(e.target.value))}
                          className="w-full accent-emerald-500 cursor-pointer h-1.5 bg-zinc-950 rounded-lg appearance-none"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <div className="flex justify-between text-[11px] font-semibold text-zinc-400">
                          <span className="flex items-center gap-1"><Sun className="w-3.5 h-3.5" /> Belichtung</span>
                          <span className="font-mono text-emerald-400">{brightness}%</span>
                        </div>
                        <input 
                          type="range" 
                          min="50" 
                          max="200" 
                          step="5" 
                          value={brightness} 
                          onChange={(e) => applyBrightness(parseInt(e.target.value))}
                          className="w-full accent-emerald-500 cursor-pointer h-1.5 bg-zinc-950 rounded-lg appearance-none"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Action Bento Card C: HARDWARE REMOTE SIGNALS */}
                  <div className="bg-zinc-900/60 rounded-2xl p-4 border border-zinc-800/80 space-y-3 shadow-md">
                    <h3 className="text-xs uppercase tracking-widest font-mono font-bold text-zinc-400 border-b border-zinc-800 pb-2 flex items-center gap-1.5">
                      <Settings className="w-4 h-4 text-emerald-400" />
                      System-Befehle
                    </h3>

                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={requestRemoteTorch}
                        className={`py-3 px-3 rounded-xl font-bold transition text-xs flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 ${
                          remoteTorchActive 
                            ? 'bg-amber-500 text-black shadow-[0_0_15px_rgba(245,158,11,0.2)]' 
                            : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-300'
                        }`}
                      >
                        <Sun className="w-4 h-4" />
                        <span>Licht drüben</span>
                      </button>

                      <button
                        onClick={requestRemoteSaver}
                        className={`py-3 px-3 rounded-xl font-bold transition text-xs flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 ${
                          remoteSaverActive 
                            ? 'bg-purple-900/50 text-purple-300 border border-purple-800' 
                            : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-300'
                        }`}
                      >
                        <Monitor className="w-4 h-4" />
                        <span>Monitor drüben aus</span>
                      </button>
                    </div>

                    <button
                      onClick={toggleFullscreen}
                      className="w-full py-3 px-4 bg-zinc-850 hover:bg-zinc-800 border border-zinc-800 hover:border-zinc-700 text-white font-semibold rounded-xl transition text-xs flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                    >
                      <Maximize2 className="w-4 h-4 text-emerald-400" />
                      <span>📺 Vollbild-Kamera (Theater-Modus)</span>
                    </button>
                  </div>

                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Hidden capturing canvas for photo triggers */}
      <canvas ref={canvasRef} style={{ display: 'none' }} />

      {/* 5. Footer area */}
      {!isFullscreen && (
        <footer className="border-t border-zinc-900 bg-black/95 py-6 px-6 text-center text-xs text-zinc-500 font-mono">
          <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-3">
            <div>
              <span>© {new Date().getFullYear()} iPad CamShare Ultimate Cockpit.</span>
            </div>
            <div className="flex gap-4 items-center">
              <span className="flex items-center gap-1"><Lock className="w-3.5 h-3.5 text-emerald-500" /> End-to-End P2P verschlüsselt</span>
              <span className="text-zinc-600">|</span>
              <span>WebRTC Direct Transport</span>
            </div>
          </div>
        </footer>
      )}
    </div>
  );
}
